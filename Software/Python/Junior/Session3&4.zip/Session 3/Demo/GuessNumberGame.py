name = input()

print("hello " + name)



print("hello to Guess number game ")

number = 10
print("Guess the number: ")

user_number = input()

if (user_number) == number:
    print("You Win!")
else:
    print("You Lose!")






print("Guess a number ")

number = 10
print("Guess the number: ")

user_number = input()

if (user_number) > number:
    print("Too High")
else:
    print("Too Low")








print("Guess a number ")

number = 10
print("Guess the number: ")

user_number = input()

if  (user_number) < number:
    print("Too Low")
else:
    print("Too High")







print("Guess a number ")

number = 10
print("Guess the number: ")

user_number = input()

if (user_number) >= number:
    print("Too Low")
else:
    print("Too High")


print("Guess a number ")

number = 10
print("Guess the number: ")

user_number = input()

if (user_number) >= number:
    print("Too High")
else:
    print("Too Low")







print("Guess a number ")

number = 10
print("Guess the number: ")

user_number = input()

if (user_number) <= number:
    print("Too Low")
else:
    print("Too High")




